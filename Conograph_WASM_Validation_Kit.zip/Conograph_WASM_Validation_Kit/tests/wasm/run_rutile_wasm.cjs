// Real execution test for compiled Conograph WASM (not a simulated result).
// Usage: node tests/wasm/run_rutile_wasm.cjs dist/conograph.js tests/rutile
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
async function main() {
  const wasmModulePath = path.resolve(process.argv[2] || 'dist/conograph.js');
  const testDir = path.resolve(process.argv[3] || 'tests/rutile');
  assert(fs.existsSync(wasmModulePath), `Compiled module is missing: ${wasmModulePath}`);
  const moduleFactory = require(wasmModulePath);
  assert.equal(typeof moduleFactory, 'function', 'MODULARIZE must export a factory function');
  const module = await moduleFactory({noInitialRun: true, print: s=>process.stdout.write(String(s)+'\n'), printErr:s=>process.stderr.write(String(s)+'\n')});
  assert(module.FS && typeof module.callMain === 'function', 'FS/callMain not exported');
  const mem = module.FS;
  mem.mkdir('/work'); mem.chdir('/work'); mem.mkdir('output');
  for (const file of ['cntl.inp.xml', 'rutile.inp.xml', 'rutile_pks.histogramIgor']) {
    mem.writeFile(file, fs.readFileSync(path.join(testDir,file)));
  }
  const started = Date.now();
  const rc = module.callMain([]);
  const elapsed = (Date.now()-started)/1000;
  console.log('Conograph WASM runtime result:',rc, `(${elapsed.toFixed(2)} s)`);
  const xmlPath='/work/output/rutile.index.xml';
  assert(mem.analyzePath(xmlPath).exists, 'Conograph did not produce its expected output/rutile.index.xml');
  const xml=mem.readFile(xmlPath,{encoding:'utf8'});
  const m=xml.match(/<SelectedLatticeCandidate\b[^>]*>([\s\S]*?)<\/SelectedLatticeCandidate>/);
  assert(m,'No selected lattice found in Conograph XML');
  const extract=name=>{
    const rx=new RegExp(`<${name}(?:\\s[^>]*)?>\\s*([\\s\\S]*?)\\s*<\\/${name}>`);
    return (m[1].match(rx)||[])[1]||'';
  };
  const system=extract('CrystalSystem').trim();
  const cell=extract('OptimizedLatticeParameters').trim().split(/\s+/).map(Number);
  const m20=Number(extract('FigureOfMeritWolff'));
  assert.equal(system,'Tetragonal(P)',`Wrong first solution: ${system}`);
  assert.equal(cell.length,6);
  for (const [i,target] of [[0,4.5937],[1,4.5937],[2,2.9587],[3,90],[4,90],[5,90]])
    assert(Math.abs(cell[i]-target)<0.005,`Wrong cell parameter ${i+1}: ${cell[i]}`);
  assert(Number.isFinite(m20) && m20>0);
  const output={engine:'Conograph WebAssembly',dataset:'synthetic rutile 15 peaks',system,cell,m20,elapsed_s:elapsed,xml_bytes:Buffer.byteLength(xml)};
  const outputPath=path.join(path.dirname(wasmModulePath),'rutile_wasm_validation.json');
  fs.writeFileSync(outputPath,JSON.stringify(output,null,2)+'\n');
  fs.writeFileSync(path.join(path.dirname(wasmModulePath),'rutile_wasm_output.index.xml'),xml);
  console.log('PASS',output);
}
main().catch(e=>{console.error('FAIL:', e.stack||e);process.exitCode=1});
