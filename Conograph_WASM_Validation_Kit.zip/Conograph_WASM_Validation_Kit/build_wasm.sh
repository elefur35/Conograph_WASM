#!/usr/bin/env bash
# Attempted WebAssembly build: Conograph C++ batch mode (MIT).
# Requires Emscripten SDK. This script is not a verified successful WASM build.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
if ! command -v em++ >/dev/null 2>&1; then
  echo 'ERROR: em++ is missing. Install/activate emsdk from https://emscripten.org/docs/getting_started/downloads.html' >&2
  exit 2
fi
if ! command -v node >/dev/null 2>&1; then
  echo 'ERROR: node is required for the smoke test.' >&2
  exit 2
fi
em++ --version | head -2
mkdir -p "$ROOT/dist"
mapfile -d '' SOURCES < <(find "$ROOT/engine/src" -name '*.cc' -print0 | sort -z)
echo "Compiling ${#SOURCES[@]} Conograph C++ files to WASM..."
em++ "${SOURCES[@]}" \
  -O2 -std=c++17 -DNDEBUG -DCONOGRAPH_BATCH \
  -Wno-unknown-pragmas \
  -sALLOW_MEMORY_GROWTH=1 \
  -sMODULARIZE=1 -sEXPORT_NAME=ConographModule \
  -sENVIRONMENT='web,worker,node' -sFORCE_FILESYSTEM=1 \
  -sEXPORTED_FUNCTIONS='["_main"]' \
  -sEXPORTED_RUNTIME_METHODS='["FS","callMain"]' \
  -sINVOKE_RUN=0 -sEXIT_RUNTIME=0 -sDISABLE_EXCEPTION_CATCHING=0 \
  -sSINGLE_FILE=1 \
  -o "$ROOT/dist/conograph.js"
echo 'Running official Conograph indexing on synthetic rutile using the WebAssembly module...'
node "$ROOT/tests/wasm/run_rutile_wasm.cjs" "$ROOT/dist/conograph.js" "$ROOT/tests/rutile"
echo 'PASS: WASM runtimes, XML output and rutile-cell check.'
