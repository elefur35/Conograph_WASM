/*
 * Conograph browser-adapter PROTOTYPE. The Conograph solver itself is not
 * implemented here. Requires a successfully compiled Emscripten module.
 * Copyright notices for Conograph are included in LICENSE.txt and source.
 */
(function (root) {
  'use strict';
  const xmlEscape = s => String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
  const finite = v => Number.isFinite(Number(v));
  function prepareIgor(profile, peaks) {
    if (!Array.isArray(profile) || profile.length < 3) throw new Error('The measured XY profile must have at least 3 points.');
    if (!Array.isArray(peaks) || peaks.length < 3) throw new Error('At least 3 selected peak positions are required.');
    const cleanProfile = profile.filter(p => finite(p.x) && finite(p.y)).map(p=>({x:Number(p.x),y:Math.max(0,Number(p.y))})).sort((a,b)=>a.x-b.x);
    const cleanPeaks = peaks.filter(p=>finite(p.twoTheta)&&finite(p.fwhm)&&Number(p.fwhm)>0).map(p=>({x:Number(p.twoTheta),y:finite(p.height)?Number(p.height):1,w:Number(p.fwhm),flag:p.selected===false?0:1})).sort((a,b)=>a.x-b.x);
    if (cleanProfile.length < 3 || cleanPeaks.filter(p=>p.flag).length < 3) throw new Error('Insufficient valid profile points or enabled peaks.');
    const lines=['IGOR','WAVES/O twoTheta, intensity, intensityError, smoothedIntensity','BEGIN'];
    for (const p of cleanProfile) lines.push([p.x.toFixed(6),p.y.toExponential(8),Math.sqrt(Math.max(1,p.y)).toExponential(8),p.y.toExponential(8)].join(' '));
    lines.push('END','WAVES/O peak, peakpos, height, FWHM, Flag','BEGIN');
    cleanPeaks.forEach((p,i)=>lines.push([i+1,p.x.toFixed(6),p.y.toExponential(8),p.w.toFixed(6),p.flag].join(' ')));
    lines.push('END');
    return lines.join('\n')+'\n';
  }
  function prepareParamXML(template, config={}) {
    if (typeof template!=='string' || !template.includes('ConographParameters')) throw new Error('An official Conograph parameter XML template is required.');
    const settings={
      IsAngleDispersion:1, WaveLength:config.wavelength??1.540598,
      ZeroPointShiftParameter:config.zero??0, SearchLevel:config.searchLevel??0,
      NumberOfThreadsToUse:1,
      MaxNumberOfPeaks:config.maxPeaks??'AUTO (20)',
      MaxNumberOfTwoDimTopographs:config.max2D??'AUTO (140)',
      MaxNumberOfLatticeCandidates:config.maxCandidates??'AUTO (19600)',
    };
    let result=template;
    for(const [tag,val] of Object.entries(settings)){
      const escaped=xmlEscape(val);
      const rx=new RegExp(`(<${tag}\\b[^>]*>)[\\s\\S]*?(<\\/${tag}>)`,'i');
      if(!rx.test(result)) throw new Error('Missing parameter: '+tag);
      result=result.replace(rx,(_all,open,close)=>open+' '+escaped+' '+close);
    }
    return result;
  }
  const controlXML=()=>`<?xml version="1.0" encoding="UTF-8"?>\n<ZCodeParameters><ConographInputFile><ControlParamFile>params.inp.xml</ControlParamFile><PeakDataFile>peaks.histogramIgor</PeakDataFile><OutputFile>output/result.index.xml</OutputFile></ConographInputFile></ZCodeParameters>`;
  function parseResults(xml) {
    if (typeof DOMParser==='undefined') throw new Error('DOMParser is needed (browser).');
    const doc=new DOMParser().parseFromString(xml,'application/xml');
    if(doc.querySelector('parsererror')) throw new Error('Invalid Conograph XML output.');
    const all=[...doc.querySelectorAll('ConographOutput > SelectedLatticeCandidate, ConographOutput > LatticeCandidate')];
    const best=new Map();
    for(const node of all){
      const get=tag=>node.querySelector(tag)?.textContent?.trim()||'';
      const system=get('CrystalSystem');
      const cell=get('OptimizedLatticeParameters').split(/\s+/).map(Number);
      const m20=Number(get('FigureOfMeritWolff'));
      if(!system||cell.length!==6||cell.some(v=>!Number.isFinite(v))) continue;
      const candidate={number:node.getAttribute('number')||'',system,cell,m20:Number.isFinite(m20)?m20:null,nIndexed:Number(get('NumberOfIndexedPeaks'))};
      const key=system+'|'+cell.map(v=>v.toFixed(3)).join('|');
      if(!best.has(key)||candidate.m20>best.get(key).m20)best.set(key,candidate);
    }
    return [...best.values()].sort((a,b)=>(b.m20??-Infinity)-(a.m20??-Infinity));
  }
  async function runCompiledModule(factory, {profile,peaks,paramsTemplate,settings}){
    if(typeof factory!=='function')throw new Error('Conograph WebAssembly module is not compiled or loaded.');
    const igor=prepareIgor(profile,peaks);
    const xml=prepareParamXML(paramsTemplate,settings);
    // A fresh instance per calculation: Conograph's CUI uses process-level static state.
    const mod=await factory({noInitialRun:true});
    const FS=mod.FS;
    FS.mkdir('/work');FS.chdir('/work');FS.mkdir('output');
    FS.writeFile('cntl.inp.xml',controlXML());
    FS.writeFile('params.inp.xml',xml);
    FS.writeFile('peaks.histogramIgor',igor);
    mod.callMain([]);
    return FS.readFile('output/result.index.xml',{encoding:'utf8'});
  }
  root.ConographBridge={prepareIgor,prepareParamXML,controlXML,parseResults,runCompiledModule};
})(typeof window!=='undefined'?window:globalThis);
