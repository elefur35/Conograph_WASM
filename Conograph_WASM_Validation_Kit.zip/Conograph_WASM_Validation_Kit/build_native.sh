#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$ROOT/obj" "$ROOT/dist"
export ROOT
find "$ROOT/engine/src" -name '*.cc' -print0 | sort -z | xargs -0 -P4 -I{} bash -c '
    src="$1"; rel="${src#"$ROOT/engine/src/"}"; obj="$ROOT/obj/${rel%.cc}.o"
    mkdir -p "$(dirname "$obj")"
    if [[ ! -s "$obj" || "$src" -nt "$obj" ]]; then
      g++ -O1 -std=c++17 -DNDEBUG -Wno-unknown-pragmas -DCONOGRAPH_BATCH -c "$src" -o "$obj"
    fi
' _ '{}'
mapfile -d '' objects < <(find "$ROOT/obj" -name '*.o' -print0 | sort -z)
g++ -O1 -std=c++17 "${objects[@]}" -o "$ROOT/dist/conograph_native_test"
echo "Built native validation executable in dist/ (NOT required by students)."
