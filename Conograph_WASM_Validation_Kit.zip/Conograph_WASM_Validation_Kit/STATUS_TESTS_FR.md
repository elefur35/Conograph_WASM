# Conograph WebAssembly — état des essais du 16 novembre 2026

## Résultats effectivement obtenus

- Sources : archive Conograph fournie par l'utilisateur, modifiées seulement pour la compatibilité C++ moderne et le mode batch ; licence MIT conservée.
- **71/71 unités de compilation** validées avec `clang++ -std=c++17 -fsyntax-only` (compilation native, pas WebAssembly).
- **Exécution native de référence réussie** sur 15 raies synthétiques du rutile : première solution Tetragonal(P), a=b=4,5937 Å et c=2,9587 Å ; XML généré (~1,55 Mo). Le M20 artificiellement élevé provient des pics parfaits.
- **Compilation avec Emscripten non réalisée** : `em++` absent, accès réseau empêchant l'installation de `emsdk`.
- `clang++ --target=wasm32-wasi` échoue pour une raison d'environnement, dès l'en-tête C++ `<limits>` : sysroot/libc++ WASM absents.

**Il n'y a PAS de fichier `.wasm` authentifié dans cette archive.** Le script de compilation est un protocole expérimental à valider, non un portage achevé.

## Compilation et contrôle reproductibles

Installer Emscripten selon https://emscripten.org/docs/getting_started/downloads.html puis dans un terminal avec `em++` et `node` accessibles :

```bash
bash build_wasm.sh
```

Le script compile les 71 fichiers C++, génère `dist/conograph.js` (WASM embarqué via SINGLE_FILE), exécute le moteur sur le rutile et vérifie automatiquement la symétrie, les paramètres et les résultats XML. Si une incompatibilité apparaît à la compilation, il faudra la corriger : aucune réussite WASM n'est affirmée ici.

Une configuration `.github/workflows/compile-wasm.yml` est également fournie pour exécuter le test dans un dépôt GitHub avec GitHub Actions, avec installation officielle du SDK sur le runner.

## Points d'attention

- WebAssembly monothread et mode batch ; OpenMP absent.
- Le module WASM n'est pas encore intégré au TP V14.3 : les étudiants continuent d'utiliser l'indexeur JS existant.
- Une fois le premier test réussi, vérifier le temps de calcul, la mémoire, les erreurs XML, puis l'exécution en Web Worker hors ligne avant tout déploiement.
- Aucune compilation `.exe` n'est prévue pour les postes étudiants ; Emscripten n'est requis que sur la machine du développeur ou le runner de compilation.
