# Conograph — préparation au portage WebAssembly pour TP DRX

**État du travail (16 novembre 2026) :** le véritable moteur Conograph C++ est compilé et validé **en natif**, y compris sous C++17 **sans OpenMP et sans dialogue interactif**. La compilation WebAssembly **n'est pas encore effectuée** : Emscripten (`em++`) n'est pas disponible dans l'environnement de construction. Aucun fichier `.wasm` vérifié n'est inclus. Ne pas présenter ce paquet comme une intégration fonctionnelle au navigateur.

## Provenance et licence

Sources : archive `ProjectPowderConograph-main.zip` fournie par l'utilisateur, issue de `https://github.com/rtomiyasu/ProjectPowderConograph`.

Licence : **MIT**. Le fichier `LICENSE.txt` et les en-têtes de copyright des auteurs sont préservés. Pour l'utilisation scientifique, citer **R. Oishi-Tomiyasu**, *Robust powder auto-indexing using many peaks*, **J. Appl. Cryst.** 47 (2014), 593–598.

## Contenu

- `engine/src/` : les 71 fichiers C++ Conograph et les en-têtes associés, avec quatre adaptations de portabilité.
- `build_native.sh` : compilation Linux en C++17, non interactive, mono-thread. **Uniquement pour validation développeur**, pas pour les postes étudiants.
- `build_wasm.sh` : projet de commande de compilation Emscripten vers un `conograph.js` qui embarque le WASM (`SINGLE_FILE`). **Script préparé mais non exécuté**.
- `web/conograph_adapter.js` : prototype de connexion entre le TP (profil XY, maxima détectés, FWHM) et le moteur compilé, dont l'interface `ConographModule` devra être confirmée.
- `web/params_template.xml` : modèle de paramètres officiel provenant de l'exemple `Cimetidine-CuKa` de Conograph.
- `tests/rutile/` : profil et pics **synthétiques** du rutile, et fichiers XML d'entrée.
- `examples/rutile_output.index.xml` : résultats du moteur natif après indexation.
- `examples/rutile_conograph_results.json` : extrait trié des résultats de contrôle.

## Modifications apportées aux sources

1. `zlog/rlog.cc` : corrige `RLog.hh` en `rlog.hh` pour un système sensible à la casse.
2. `utility_data_structure/Bud.hh` : déplace l'argument par défaut d'une déclaration `friend` vers une déclaration libre (compatibilité compilateurs modernes).
3. `utility_func/stopx.hh` et `.cc` : supprime une spécification dynamique d'exceptions supprimée en C++17, sans modifier le corps du contrôle d'interruption.
4. `main_indexing.cc` : avec `CONOGRAPH_BATCH`, le programme quitte après l'export `*.index.xml`, sans saisir un numéro de maille au clavier. Cela conserve **l'indexation**, mais **ne réalise pas l'affinement interactif** d'une solution choisie (phase de travail suivante).

Le code mathématique d'indexation a été conservé.

## Tests effectivement réalisés

### A. Logiciel officiel de référence, GCC (OpenMP)

- Compilation réussie après compatibilité C++11 et correction du nom d'en-tête.
- Exécution sur l'exemple officiel `sample4` (cimétidine, Cu Kα) : lecture des données, génération des topographes, classement des réseaux de Bravais, production de `output/Cimetidine-CuKa.index.xml`.

### B. Variante portable C++17, mono-thread, sans interaction

- Compilation terminée avec les 71 fichiers C++.
- Exécution sur 15 raies **synthétiques** de rutile : première solution `Tetragonal(P)` : **a=b=4,5937 Å, c=2,9587 Å**. Les coordonnées initiales étaient exactement celles-ci. Le `M20` très élevé provient de positions de pics simulées avec une précision quasi parfaite ; il n'a pas de valeur expérimentale représentative.
- XML produit et analysé : les autres mailles (orthorhombiques, etc.) montrent l'intérêt de présenter plusieurs candidats concurrents.

**Ces tests ne démontrent pas encore le fonctionnement WebAssembly ni la fiabilité sur des données expérimentales, en particulier multiphasées.**

## Commandes développeur (Linux)

```bash
./build_native.sh
cd tests/rutile
../../dist/conograph_native_test
# Produit output/rutile.index.xml sans dialogue interactif.
```

Pour une compilation WebAssembly (après installation de l'outil Emscripten chez le développeur) :

```bash
source /chemin/vers/emsdk/emsdk_env.sh
./build_wasm.sh
# Commande encore à valider : devrait générer dist/conograph.js
```

L'option `-sSINGLE_FILE=1` est prévue pour embarquer le binaire WASM dans JavaScript ; il restera ensuite à intégrer ce JavaScript dans **un seul HTML** et à isoler le calcul dans un **Web Worker** pour ne pas bloquer l'interface. Les étudiants n'auront rien à installer.

## Raccordement prévu à la V14.3

**Étape 1 :** récupérer courbe XY, maxima, intensités, FWHM et incertitudes. **Étape 2 :** après échec de la recherche Search–Match sur la bibliothèque CIF, proposer « Indexer une phase inconnue ». Le moteur reçoit les données sans les convertir en pics artificiels. Il propose des candidats avec paramètres et critères de qualité. L'étudiant inspecte les positions calculées, les pics non indexés et les solutions alternatives ; il choisit explicitement une maille à transmettre au *profile matching*.

Ne pas utiliser directement le moteur monophasé sur un mélange complexe : il faut d'abord isoler ou sélectionner de manière documentée les réflexions non expliquées. Une réflexion non indexée peut provenir d'une phase secondaire, d'une impureté, d'un pic parasite ou d'une erreur de détection.

## Points techniques restant ouverts

- Compiler réellement avec Emscripten et traiter toute éventuelle incompatibilité spécifique Clang/WASM.
- Tester l'interface `ConographModule`, le système de fichiers virtuel et le traitement des exceptions.
- **Supprimer toute saisie interactive** : le mode batch actuel saute la seconde passe d'affinement ; une API C++ dédiée permettra ultérieurement de demander l'affinement d'une maille choisie.
- Exécuter dans un Web Worker avec indicateur d'activité, gestion du temps maximal et possibilité d'annuler.
- Valider les scores sur rutile, ZnO, NaCl et jeux expérimentaux monophases, puis seulement sur des mélanges.
- Conserver la licence et les références dans le HTML autonome.

**Ne pas distribuer `dist/conograph_native_test` aux étudiants.** Il ne figure pas dans le ZIP de sources destiné au portage.
